import time

_last_signal = {}


def anti_spam(symbol, direction, cooldown=900):
    key = f"{symbol}_{direction}"
    now = time.time()

    last_time = _last_signal.get(key, 0)

    if now - last_time < cooldown:
        return False, "signal cooldown"

    _last_signal[key] = now
    return True, "ok"