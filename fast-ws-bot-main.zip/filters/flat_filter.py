def is_flat_market(bb_width, atr_percent):
    if bb_width < 0.018 and atr_percent < 0.012:
        return True, "flat market"

    return False, "market active"