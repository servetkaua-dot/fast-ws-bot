def get_trend(price, ema_fast, ema_slow):
    if price > ema_fast and ema_fast > ema_slow:
        return "UP"

    if price < ema_fast and ema_fast < ema_slow:
        return "DOWN"

    return "SIDEWAYS"


def trend_allows(direction, price, ema_fast, ema_slow):
    trend = get_trend(price, ema_fast, ema_slow)

    if direction == "LONG" and trend == "DOWN":
        return False, "LONG blocked: downtrend"

    if direction == "SHORT" and trend == "UP":
        return False, "SHORT blocked: uptrend"

    return True, f"trend ok: {trend}"