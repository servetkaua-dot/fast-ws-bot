def liquidation_bias(context):
    above = context.get("above_liquidity", 0)
    below = context.get("below_liquidity", 0)

    if above > below * 1.5:
        return "LONG", "liquidity above price"

    if below > above * 1.5:
        return "SHORT", "liquidity below price"

    return "NEUTRAL", "balanced liquidity"


def liquidation_score(direction, context):
    bias, reason = liquidation_bias(context)

    if bias == direction:
        return 15, reason

    if bias == "NEUTRAL":
        return 0, reason

    return -10, f"opposite liquidity bias: {reason}"