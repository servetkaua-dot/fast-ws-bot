from filters.liquidation_filter import liquidation_score


def calculate_score(
    direction,
    trend_ok,
    volume_spike,
    multi_tf_ok,
    flat_market,
    heatmap_context,
    rsi=None
):
    score = 0
    reasons = []

    if flat_market:
        return 0, ["blocked: flat market"]

    if trend_ok:
        score += 25
        reasons.append("trend ok")
    else:
        score -= 25
        reasons.append("trend weak")

    if volume_spike:
        score += 15
        reasons.append("volume spike")

    if multi_tf_ok:
        score += 20
        reasons.append("multi-timeframe ok")

    liq_score, liq_reason = liquidation_score(direction, heatmap_context)
    score += liq_score
    reasons.append(liq_reason)

    if rsi is not None:
        if direction == "LONG" and rsi < 35:
            score += 10
            reasons.append("RSI oversold")

        if direction == "SHORT" and rsi > 65:
            score += 10
            reasons.append("RSI overbought")

    score = max(0, min(score, 100))

    return score, reasons


def signal_level(score):
    if score >= 80:
        return "VIP"

    if score >= 65:
        return "STRONG"

    if score >= 55:
        return "NORMAL"

    return "WEAK"