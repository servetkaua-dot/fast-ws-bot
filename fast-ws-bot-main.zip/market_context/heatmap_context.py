import json
import os
import time

CACHE_FILE = "cache/liquidations.json"
CACHE_TTL = 300  # 5 минут


def load_heatmap_cache():
    if not os.path.exists(CACHE_FILE):
        return None

    try:
        with open(CACHE_FILE, "r") as f:
            data = json.load(f)

        if time.time() - data.get("updated_at", 0) > CACHE_TTL:
            return None

        return data

    except Exception:
        return None


def save_heatmap_cache(symbol, clusters):
    data = {
        "symbol": symbol,
        "updated_at": time.time(),
        "clusters": clusters
    }

    with open(CACHE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def get_mock_heatmap(price):
    """
    Временная заглушка.
    Потом сюда подключим CoinGlass / Hyblock / Binance.
    """
    return [
        {"price": price * 1.01, "size": 120},
        {"price": price * 1.02, "size": 180},
        {"price": price * 0.99, "size": 90},
        {"price": price * 0.98, "size": 70},
    ]


def get_heatmap_context(symbol, price):
    cached = load_heatmap_cache()

    if cached and cached.get("symbol") == symbol:
        clusters = cached.get("clusters", [])
    else:
        clusters = get_mock_heatmap(price)
        save_heatmap_cache(symbol, clusters)

    above = [c for c in clusters if c["price"] > price]
    below = [c for c in clusters if c["price"] < price]

    above_liquidity = sum(c["size"] for c in above)
    below_liquidity = sum(c["size"] for c in below)

    nearest_above = min(above, key=lambda x: abs(x["price"] - price), default=None)
    nearest_below = min(below, key=lambda x: abs(x["price"] - price), default=None)

    return {
        "above_liquidity": above_liquidity,
        "below_liquidity": below_liquidity,
        "nearest_above": nearest_above,
        "nearest_below": nearest_below,
        "clusters": clusters
    }